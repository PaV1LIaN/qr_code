<?
$sSectionName="qr_opros";
?>